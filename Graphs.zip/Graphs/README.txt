Initializing the SAS paths accordingly, it is possible to obtain the graphs of these folders, via

$fplot rateEPIC.fits offset=yes
Name of X Axis Parameter[error][TIME] 
Name of Y Axis Parameter[error] up to 8 allowed[RATE] 
Lists of rows[-] 
Device: /XWindow, /XTerm, /TK, /PS, etc[/xs] /xs
Any legal PLT command[ ] 

were "EPIC" stands for EPN, EMOS1 and EMOS2. This was done in order to choose the best threshold for GTI filtering.
